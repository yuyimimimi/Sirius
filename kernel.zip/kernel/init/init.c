#include <linux/init.h>

#include "esp_system.h"
#include <stdio.h>

void __init system_boot(void);


void __init __init__(void) 
{

    system_boot();
}

