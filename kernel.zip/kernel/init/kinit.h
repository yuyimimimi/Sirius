#ifndef __INIT_H__
#define __INIT_H__
#include <linux/init.h>
#include <linux/module.h>
void start_console(void);


void __init __init__(void); // 内核一级引导回调函数

// void __init __attribute__((constructor)) init(void)                 //只有rsicv gcc支持module_init 如果不引导请切换为这个
// {
//     __init__();
// }

module_init(__init__);


void app_main(){start_console();}//main不重要


#endif
