#define __CAT_H__
#ifdef  __CAT_H__    
    /* Function to get the console path */
    char *get_console_path();
    void set_console_path(const char* path);
#endif
