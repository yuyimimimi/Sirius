#ifndef _LINUX_WIRELESS_H
#define _LINUX_WIRELESS_H

#include <uapi/linux/wireless.h>




#endif	/* _LINUX_WIRELESS_H */