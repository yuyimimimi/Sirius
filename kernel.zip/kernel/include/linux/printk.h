#define __PINTK_H__
#ifdef __PINTK_H__

#include "esp_log.h"
#include "raid/xor.h"

#define KERN_INFO       
#define KERN_WARNING    
#define KERN_ERR     
   
#endif
