#define __INIT__
#ifdef __INIT__

#define __init
#define __exit



#endif