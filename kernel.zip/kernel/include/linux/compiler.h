#ifndef _LINUX_COMPILER_H
#define _LINUX_COMPILER_H





#endif /* _LINUX_COMPILER_H */