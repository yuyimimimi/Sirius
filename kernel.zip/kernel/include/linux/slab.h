#define _slab_h_
#ifdef _slab_h_

#define vmalloc malloc
#define vfree free

#endif 