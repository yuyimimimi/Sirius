/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * i2c.h - definitions for the Linux i2c bus interface
 * Copyright (C) 1995-2000 Simon G. Vogl
 * Copyright (C) 2013-2019 Wolfram Sang <wsa@kernel.org>
 *
 * With some changes from Kyösti Mälkki <kmalkki@cc.hut.fi> and
 * Frodo Looijaard <frodol@dds.nl>
 */

#ifndef _LINUX_I2C_H
#define _LINUX_I2C_H

#include <linux/types.h>
#include <uapi/linux/i2c.h>
#include <linux/bits.h>
#include <linux/mutex.h>


/*
i2c_adapter对应物理上的一个适配器，也就是指的是CPU内部的I
2C控制器，一个CPU内部可能有多个I2c适配器。而i2c_algorithm
对应一套通信方法，一个i2c适配器需要i2c_algorithm中提供的通
信函数来控制适配器产生特定的访问周期，缺少i2c_algorithm的i2
c_adapter什么也做不了，因此i2c_adapter中包含其使用i2c_algorithm的指针。
 */
struct i2c_adapter {

};


struct i2c_driver {

};

struct i2c_client{

};

struct i2c_algorithm{

};



#endif /* _LINUX_I2C_H */ 