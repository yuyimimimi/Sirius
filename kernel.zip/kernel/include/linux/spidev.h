#ifndef _LINUX_SPI_SPI_H
#define _LINUX_SPI_SPI_H

#include <linux/ioctl.h>

#define SPI_IOC_RD_MODE _IOR('k', 0, __u8)


#endif /* _LINUX_SPI_SPI_H */