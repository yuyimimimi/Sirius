#ifndef _LINUX_BITS_H
#define _LINUX_BITS_H
#include <linux/compiler.h>
#include <linux/types.h>



#endif /* _LINUX_BITS_H */